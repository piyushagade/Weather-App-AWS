export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyCOwzHSWAYL2cYRF7t7MCVF9I2W8LRzlvo",
    authDomain: "skycast-pa-aws.firebaseapp.com",
    databaseURL: "https://skycast-pa-aws.firebaseio.com",
    projectId: "skycast-pa-aws",
    storageBucket: "skycast-pa-aws.appspot.com",
    messagingSenderId: "359491823283"
  }
};
